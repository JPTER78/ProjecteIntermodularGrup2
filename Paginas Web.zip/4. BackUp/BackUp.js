window.onload = function() {
    document.getElementById('div').style.display = "none";

}

function mostraBackup() {
    document.getElementById('div').style.display = "grid";
}