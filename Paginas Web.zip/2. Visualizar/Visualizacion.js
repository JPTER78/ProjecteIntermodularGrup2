window.onload = function() {
    document.getElementById("div").style.display = "none";
}

function Visualizar() {
    document.getElementById('div').style.display = "grid";

}