package controladors;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.application.Platform;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import objectes.Usuari;

public class VistaAplicacioBaseController implements Initializable {
	
	@FXML private VBox root;
	@FXML private Label fitxer;
	@FXML private VBox fitxerDesplegable;
	@FXML private Label fitxerSub1;
	@FXML private Label fitxerSub2;
	@FXML private Label fitxerSub3;
	@FXML private Label fitxerSub4;
	@FXML private Label fitxerSub5;
	@FXML private Label fitxerSub6;
	@FXML private Label edita;
	@FXML private VBox editaDesplegable;
	@FXML private Label editaSub1;
	@FXML private Label editaSub2;
	@FXML private Label editaSub3;
	@FXML private Label visualitza;
	@FXML private VBox visualitzaDesplegable;
	@FXML private Label visualitzaSub1;
	@FXML private Label visualitzaSub2;
	@FXML private Label visualitzaSub3;
	@FXML private Label visualitzaSub4;
	@FXML private Label quantA;
	@FXML private VBox quantaDesplegable;
	@FXML private Label quantaSub1;
	@FXML private Label quantaSub2;
	@FXML private ImageView imatgeUser;
	@FXML private Label benvingut;
	
	public void mostrarFitxer() {
		if (fitxerDesplegable.isVisible()) {
			fitxerDesplegable.setVisible(false);
		} else {
			fitxerDesplegable.setVisible(true);
			editaDesplegable.setVisible(false);
			visualitzaDesplegable.setVisible(false);
			quantaDesplegable.setVisible(false);
		}
	}
	
	public void mostrarEdita() {
		if (editaDesplegable.isVisible()) {
			editaDesplegable.setVisible(false);
		} else {
			editaDesplegable.setVisible(true);
			fitxerDesplegable.setVisible(false);
			visualitzaDesplegable.setVisible(false);
			quantaDesplegable.setVisible(false);
		}
	}

	public void mostrarVisualitza() {
		if (visualitzaDesplegable.isVisible()) {
			visualitzaDesplegable.setVisible(false);
		} else {
			visualitzaDesplegable.setVisible(true);
			fitxerDesplegable.setVisible(false);
			editaDesplegable.setVisible(false);
			quantaDesplegable.setVisible(false);
		}
	}
	
	public void mostrarQuantA() {
		if (quantaDesplegable.isVisible()) {
			quantaDesplegable.setVisible(false);
		} else {
			quantaDesplegable.setVisible(true);
			fitxerDesplegable.setVisible(false);
			editaDesplegable.setVisible(false);
			visualitzaDesplegable.setVisible(false);
		}
	}
	
	public void alumbrar() {
		ArrayList<Label> arrayLabels = carregarArray();
		for (int i = 0; i < arrayLabels.size(); i++) {
			if (arrayLabels.get(i).isHover()) {
				arrayLabels.get(i).setTextFill(Color.web("#d3d3d3"));
			}
		}
	}

	public void deslumbrar() {
		ArrayList<Label> arrayLabels = carregarArray();
		for (int i = 0; i < arrayLabels.size(); i++) {
			if (!arrayLabels.get(i).isHover()) {
				arrayLabels.get(i).setTextFill(Color.web("#a1a1a1"));
			}
		}
	}
	
	public ArrayList<Label> carregarArray() {
		ArrayList<Label> arrayLabels = new ArrayList<Label>();
		arrayLabels.add(fitxer);
		arrayLabels.add(fitxerSub1);
		arrayLabels.add(fitxerSub2);
		arrayLabels.add(fitxerSub3);
		arrayLabels.add(fitxerSub4);
		arrayLabels.add(fitxerSub5);
		arrayLabels.add(fitxerSub6);
		arrayLabels.add(edita);
		arrayLabels.add(editaSub1);
		arrayLabels.add(editaSub2);
		arrayLabels.add(editaSub3);
		arrayLabels.add(visualitza);
		arrayLabels.add(visualitzaSub1);
		arrayLabels.add(visualitzaSub2);
		arrayLabels.add(visualitzaSub3);
		arrayLabels.add(quantA);
		arrayLabels.add(quantaSub1);
		arrayLabels.add(quantaSub2);
		return arrayLabels;
	}
	
	public void afegirElementGeneral (Event e) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/vistes/VistaAfegirElementGeneral.fxml"));
			Scene escena = new Scene(root);
			Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
			Usuari usuariApp = (Usuari) window.getUserData();
			window.setScene(escena);
			window.setUserData(usuariApp);
			window.setTitle("Afegir Element General");
			window.show();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	
	public void afegirElementPersonal (Event e) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/vistes/VistaAfegirElementPersonal.fxml"));
			Scene escena = new Scene(root);
			Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
			Usuari usuariApp = (Usuari) window.getUserData();
			window.setScene(escena);
			window.setUserData(usuariApp);
			window.setTitle("Afegir Element Personal");
			window.show();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	
	public void exportarElements (Event e) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/vistes/VistaExportarElements.fxml"));
			Scene escena = new Scene(root);
			Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
			Usuari usuariApp = (Usuari) window.getUserData();
			window.setScene(escena);
			window.setUserData(usuariApp);
			window.setTitle("Exportar Elements");
			window.show();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	
	public void donarBaixa (Event e) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/vistes/VistaLogin.fxml"));
			Scene escena = new Scene(root);
			Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
			
			Usuari usuariApp = (Usuari) window.getUserData();
			
        	Class.forName("org.mariadb.jdbc.Driver");
			
			String urlBaseDades = "jdbc:mysql://localhost:3306/Equip2PI";
			String usuari = "root";
			String contrasenya = "";
			
        	Connection c = DriverManager.getConnection(urlBaseDades , usuari, contrasenya);
			Statement s = c.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
			s.executeUpdate("DELETE FROM Usuari WHERE IDUsuari = " + usuariApp.getIdUsuari());
			
			window.setScene(escena);
			window.setTitle("Login");
			window.show();
        } catch (Exception e3) {
			System.out.println("Error: " + e3);
		}
	}
	
	public void tancarSessio (Event e) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/vistes/VistaLogin.fxml"));
			Scene escena = new Scene(root);
			Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
			window.setScene(escena);
			window.setTitle("Login");
			window.show();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	
	public void eixirAplicacio (Event e) {
		Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
		window.close();
	}
	
	public void cercarElement (Event e) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/vistes/VistaCercarElement.fxml"));
			Scene escena = new Scene(root);
			Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
			Usuari usuariApp = (Usuari) window.getUserData();
			window.setScene(escena);
			window.setUserData(usuariApp);
			window.setTitle("Cercar Element");
			window.show();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	
	public void eliminarElement (Event e) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/vistes/VistaEliminarElement.fxml"));
			Scene escena = new Scene(root);
			Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
			Usuari usuariApp = (Usuari) window.getUserData();
			window.setScene(escena);
			window.setUserData(usuariApp);
			window.setTitle("Eliminar Element");
			window.show();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	
	public void modificarElement (Event e) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/vistes/VistaModificarElement.fxml"));
			Scene escena = new Scene(root);
			Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
			Usuari usuariApp = (Usuari) window.getUserData();
			window.setScene(escena);
			window.setUserData(usuariApp);
			window.setTitle("Modificar Element");
			window.show();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	
	public void mostrarGeneral (Event e) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/vistes/VistaMostrarSeriesGenerals.fxml"));
			Scene escena = new Scene(root);
			Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
			Usuari usuariApp = (Usuari) window.getUserData();
			window.setScene(escena);
			window.setUserData(usuariApp);
			window.setTitle("Mostrar Series Generals");
			window.show();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	
	public void mostrarPersonal (Event e) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/vistes/VistaMostrarSeriesPersonals.fxml"));
			Scene escena = new Scene(root);
			Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
			Usuari usuariApp = (Usuari) window.getUserData();
			window.setScene(escena);
			window.setUserData(usuariApp);
			window.setTitle("Mostrar Series Personals");
			window.show();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	
	public void mostrarUsuaris (Event e) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/vistes/VistaMostrarUsuaris.fxml"));
			Scene escena = new Scene(root);
			Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
			Usuari usuariApp = (Usuari) window.getUserData();
			window.setScene(escena);
			window.setUserData(usuariApp);
			window.setTitle("Mostrar Usuaris");
			window.show();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	
	public void mostrarMissatges (Event e) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/vistes/VistaMostrarMissatgesEnviats.fxml"));
			Scene escena = new Scene(root);
			Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
			Usuari usuariApp = (Usuari) window.getUserData();
			window.setScene(escena);
			window.setUserData(usuariApp);
			window.setTitle("Missatges Enviats");
			window.show();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	
	public void modificarPerfil (Event e) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/vistes/VistaModificarPerfil.fxml"));
			Scene escena = new Scene(root);
			Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
			Usuari usuariApp = (Usuari) window.getUserData();
			window.setScene(escena);
			window.setUserData(usuariApp);
			window.setTitle("Modificar Perfil");
			window.show();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	
	public void mostrarInformacio (Event e) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/vistes/VistaMostrarInformacio.fxml"));
			Scene escena = new Scene(root);
			Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
			Usuari usuariApp = (Usuari) window.getUserData();
			window.setScene(escena);
			window.setUserData(usuariApp);
			window.setTitle("Mostrar Informació");
			window.show();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			Platform.runLater(() -> {
				Stage window = (Stage) root.getScene().getWindow();
				Usuari usuariApp = (Usuari) window.getUserData();
				benvingut.setText("Benvingut " + usuariApp.getNomUsuari() + " " + usuariApp.getCognomsUsuari());
			});
		} catch (Exception e) {
			
		}
	}
	
}