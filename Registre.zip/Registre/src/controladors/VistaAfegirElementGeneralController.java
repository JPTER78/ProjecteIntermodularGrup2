package controladors;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import objectes.Usuari;

public class VistaAfegirElementGeneralController {
	
	@FXML private VBox root;
	@FXML private RadioButton peliculaRB;
	@FXML private RadioButton serieRB;
	@FXML private TextField any;
	@FXML private TextField titul;
	@FXML private TextField genere;
	@FXML private TextField duracio;
	@FXML private TextField temporades;
	@FXML private TextArea interprets;
	@FXML private TextField direccio;
	@FXML private TextArea sinopsi;
	@FXML private TextField nota;
	@FXML private Label error;
	@FXML private Button botoEixir;
	@FXML private Button botoBorrarDades;
	@FXML private Button botoAfegir;
	
	public void eixirAfegir (ActionEvent e) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/vistes/VistaAplicacioBase.fxml"));
			Scene escena = new Scene(root);
			Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
			window.setScene(escena);
			window.setTitle("MovieRater");
			window.show();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	
	public void esborrarDades (ActionEvent e) {
		peliculaRB.setSelected(false);
		serieRB.setSelected(false);
		any.setText("");
		titul.setText("");
		genere.setText("");
		duracio.setText("");
		temporades.setText("");
		interprets.setText("");
		direccio.setText("");
		sinopsi.setText("");
		nota.setText("");
        error.setText("");
	}
	
	public void afegirElement (ActionEvent e) {
		Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
		Usuari usuariApp = (Usuari) window.getUserData();
		if (peliculaRB.isSelected()) {
			try {
				String tipus = "General";
				String anyP = any.getText().trim();
				String titulP = titul.getText().trim();
				String genereP = genere.getText().trim();
				String duradaP = duracio.getText().trim();
				String interpretsP = interprets.getText().trim();
				String direccioP = direccio.getText().trim();
				String sinopsiP = sinopsi.getText().trim();
				String notaP = nota.getText().trim();
				int idUser = usuariApp.getIdUsuari();
				
				error.setStyle("-fx-text-fill: red;");
				if (anyP.isEmpty() || titulP.isEmpty() || genereP.isEmpty() || duradaP.isEmpty() || interpretsP.isEmpty() || direccioP.isEmpty() || sinopsiP.isEmpty() || notaP.isEmpty()) {
					error.setText("Tots els camps són obligatoris");
				} else if (!anyP.matches("(19\\d{2})") && !anyP.matches("(20\\d{2})")) {
					error.setText("L'any no es vàlid");
				} else if (!duradaP.matches("\\d*")) {
					error.setText("La duració no es vàlida, has de escriure solament les hores");
				} else if (!duradaP.matches("\\d{1,3}")) {
					error.setText("La duració no pot ser superior a 999h o inferior a 0h");
				} else if (!notaP.matches("\\d") && !notaP.matches("10")) {
					error.setText("La nota no es vàlida");
				} else {
					Class.forName("org.mariadb.jdbc.Driver");
					
					String urlBaseDades = "jdbc:mysql://localhost:3306/Equip2PI";
					String usuariBD = "root";
					String contrasenyaBD = "";
					
					Connection c = DriverManager.getConnection(urlBaseDades, usuariBD, contrasenyaBD);
					Statement s = c.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
	    			s.executeUpdate("INSERT INTO Peliculas (NomPeli, Genere, Nota, Any, Durada, Interprets, Direccio, Sinopsi, IDUsuario, TipusElement) VALUES ('" + titulP + "', '" + genereP + "', '" + notaP + "', '" + anyP + "', '" + duradaP + "', '" + interpretsP + "', '" + direccioP + "', '" + sinopsiP + "', " + idUser + ", '" + tipus + "')");
	    			error.setStyle("-fx-text-fill: green;");
	    			error.setText("Película afegida satisfactoriament");
				}
			} catch (Exception e2) {
				error.setStyle("-fx-text-fill: red;");
				error.setText("Ha ocurrit un error, avisa al programador xd");
				System.out.println("Error: " + e2);
			}
		} else if (serieRB.isSelected()) {
			try {
				String tipus = "General";
				String anyS = any.getText().trim();
				String titulS = titul.getText().trim();
				String genereS = genere.getText().trim();
				String duradaS = duracio.getText().trim();
				String temporadesS = duracio.getText().trim();
				String interpretsS = interprets.getText().trim();
				String direccioS = direccio.getText().trim();
				String sinopsiS = sinopsi.getText().trim();
				String notaS = nota.getText().trim();
				int idUser = usuariApp.getIdUsuari();
					
				error.setStyle("-fx-text-fill: red;");
				if (anyS.isEmpty() || titulS.isEmpty() || genereS.isEmpty() || duradaS.isEmpty() || temporadesS.isEmpty() || interpretsS.isEmpty() || direccioS.isEmpty() || sinopsiS.isEmpty() || notaS.isEmpty()) {
					error.setText("Tots els camps són obligatoris");
				} else if (!anyS.matches("(19\\d{2})") && !anyS.matches("(20\\d{2})")) {
					error.setText("L'any no es vàlid");
				} else if (!duradaS.matches("\\d*")) {
					error.setText("La duració no es vàlida, has de escriure solament les hores");
				} else if (!duradaS.matches("\\d{1,3}")) {
					error.setText("La duració no pot ser superior a 999h o inferior a 0h");
				} else if (!temporadesS.matches("\\d{1,2}")) {
					error.setText("Les temporades no són vàlides");
				} else if (!notaS.matches("\\d") && !notaS.matches("10")) {
					error.setText("La nota no es vàlida");
				} else {
					Class.forName("org.mariadb.jdbc.Driver");
					
					String urlBaseDades = "jdbc:mysql://localhost:3306/Equip2PI";
					String usuariBD = "root";
					String contrasenyaBD = "";
					
					Connection c = DriverManager.getConnection(urlBaseDades, usuariBD, contrasenyaBD);
					Statement s = c.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
	    			s.executeUpdate("INSERT INTO Series (NomSerie, Temporades, Any, Genere, Durada, Interprets, Direccio, Sinopsi, Nota, IDUsuario, TipusElement) VALUES ('" + titulS + "', '" + temporadesS + "', '" + anyS + "', '" + genereS + "', '" + duradaS + "', '" + interpretsS + "', '" + direccioS + "', '" + sinopsiS + "', '" + notaS + "', " + idUser + ", '" + tipus + "')");
	    			error.setStyle("-fx-text-fill: green;");
	    			error.setText("Serie afegida satisfactoriament");
				}
			} catch (Exception e2) {
				error.setStyle("-fx-text-fill: red;");
				error.setText("Ha ocurrit un error, avisa al programador xd");
				System.out.println("Error: " + e2);
			}
		} else {
			error.setStyle("-fx-text-fill: red;");
			error.setText("Tots els camps són obligatoris");
		}
	}
	
	public void desactivarTemporades (Event e) {
		temporades.setText("");
		temporades.setDisable(true);
	}
	
	public void activarTemporades (Event e) {
		temporades.setDisable(false);
	}
	
	
}