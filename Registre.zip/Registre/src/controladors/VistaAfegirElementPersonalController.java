package controladors;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import objectes.Usuari;

public class VistaAfegirElementPersonalController implements Initializable {

    @FXML private VBox root;
    @FXML private VBox vBoxMostrar;
    @FXML private Button botoEixir;

    public void eixirAfegirPersonal (ActionEvent e) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/vistes/VistaAplicacioBase.fxml"));
            Scene escena = new Scene(root);
            Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
            window.setScene(escena);
            window.setTitle("MovieRater");
            window.show();
        } catch (IOException e1) {
            e1.printStackTrace();
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        Platform.runLater(() -> {
            Stage window = (Stage) root.getScene().getWindow();
            Usuari usuariApp = (Usuari) window.getUserData();
            String nomTaulaPelicules = usuariApp.getCorreuUsuari().split("@")[0] + "PeliculesPersonals";
            String nomTaulaSeries = usuariApp.getCorreuUsuari().split("@")[0] + "SeriesPersonals";
            try {
                Class.forName("org.mariadb.jdbc.Driver");
                
                String urlBaseDades = "jdbc:mysql://localhost:3306/Equip2PI";
                String usuari = "root";
                String contrasenya = "";
                
                Connection c = DriverManager.getConnection(urlBaseDades, usuari, contrasenya);
                Statement s = c.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
                ResultSet r = s.executeQuery("SELECT * FROM Peliculas");
                
                while (r.next()) {
                    boolean personal = comprovarPersonal(c, r, nomTaulaPelicules, "Peli");
                    if (!personal) {
                        Label pelicula = new Label("Pelicula");
                        Label nom = new Label(r.getString("NomPeli"));
                        Label any = new Label(r.getString("Any"));
                        Button botoAfegir = new Button();
                        botoAfegir.setText("Afegir " + r.getInt("IDPeli"));
                        botoAfegir.setOnAction(new EventHandler<ActionEvent>() {
                            public void handle(ActionEvent event) {
                                try {
                                    String idPelicula = ((Button) event.getSource()).getText().split(" ")[1];
                                    Statement s3 = c.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
                                    ResultSet r3 = s3.executeQuery("SELECT * FROM Peliculas WHERE IDPeli = " + idPelicula);
                                    if (r3.next()) {
                                        s3.executeUpdate("INSERT INTO " + nomTaulaPelicules + " (IDPeli, NomPeli, Genere, Nota, Any, Durada, Interprets, Direccio, Sinopsi) VALUES (" + r3.getInt("IDPeli") + ", '" + r3.getString("NomPeli") + "', '" + r3.getString("Genere") + "', " + r3.getInt("Nota") + ", " + r3.getInt("Any") + ", " + r3.getInt("Durada") + ", '" + r3.getString("Interprets") + "', '" + r3.getString("Direccio") + "', '" + r3.getString("Sinopsi") + "')");
                                        vBoxMostrar.getChildren().remove(botoAfegir.getParent());
                                    }
                                    r3.close();
                                    s3.close();
                                } catch (Exception e2) {
                                    System.out.println("Error: " + e2);
                                }
                            }
                        });
                        pelicula.setPadding(new Insets(10,10,10,10));
                        nom.setPadding(new Insets(10,10,10,10));
                        any.setPadding(new Insets(10,10,10,10));
                        HBox hBoxPelicula = new HBox(pelicula, nom, any, botoAfegir);
                        hBoxPelicula.setAlignment(Pos.CENTER);
                        vBoxMostrar.getChildren().add(hBoxPelicula);
                    }
                }

                Statement s2 = c.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
                ResultSet r2 = s2.executeQuery("SELECT * FROM Series");
                while (r2.next()) {
                    boolean personal2 = comprovarPersonal(c, r2, nomTaulaSeries, "Serie");
                    if (!personal2) {
                        Label pelicula = new Label("Serie");
                        Label nom = new Label(r2.getString("NomSerie"));
                        Label any = new Label(r2.getString("Any"));
                        Button botoAfegir = new Button();
                        botoAfegir.setText("Afegir " + r2.getInt("IDSerie"));
                        botoAfegir.setOnAction(new EventHandler<ActionEvent>() {
                            public void handle(ActionEvent event) {
                                try {
                                    String idSerie = ((Button) event.getSource()).getText().split(" ")[1];
                                    Statement s4 = c.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
                                    ResultSet r4 = s4.executeQuery("SELECT * FROM Series WHERE IDSerie = " + idSerie);
                                    if (r4.next()) {
                                        s4.executeUpdate("INSERT INTO " + nomTaulaSeries + " (IDSerie, NomSerie, Temporades, Any, Genere, Durada, Interprets, Direccio, Sinopsi, Nota) VALUES (" + r4.getInt("IDSerie") + ", '" + r4.getString("NomSerie") + "', " + r4.getInt("Temporades") + ", " + r4.getInt("Any") + ", '" + r4.getString("Genere") + "', " + r4.getInt("Durada") + ", '" + r4.getString("Interprets") + "', '" + r4.getString("Direccio") + "', '" + r4.getString("Sinopsi") + "', " + r4.getInt("Nota") + ")");
                                        vBoxMostrar.getChildren().remove(botoAfegir.getParent());
                                    }
                                    r4.close();
                                    s4.close();
                                } catch (Exception e2) {
                                    System.out.println("Error: " + e2);
                                }
                            }
                        });
                        pelicula.setPadding(new Insets(10,10,10,10));
                        nom.setPadding(new Insets(10,10,10,10));
                        any.setPadding(new Insets(10,10,10,10));
                        HBox hBoxPelicula = new HBox(pelicula, nom, any, botoAfegir);
                        hBoxPelicula.setAlignment(Pos.CENTER);
                        vBoxMostrar.getChildren().add(hBoxPelicula);
                    }
                }
            } catch (Exception e2) {
                System.out.println("Error: " + e2);
            }
        });
    }

    public boolean comprovarPersonal(Connection c, ResultSet r, String nomTaula, String tipo) {
        boolean personal = false;
        try {
            Statement s2 = c.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
            ResultSet r5 = null;
            if (tipo.equals("Peli")) {
                r5 = s2.executeQuery("SELECT * FROM " + nomTaula + " WHERE IDPeli = " + r.getInt("IDPeli"));
            } else if (tipo.equals("Serie")) {
                r5 = s2.executeQuery("SELECT * FROM " + nomTaula + " WHERE IDSerie = " + r.getInt("IDSerie"));
            }
            if (r5 != null && r5.next()) {
                personal = true;
                r5.close();
            }
            s2.close();
        } catch (Exception e) {
            System.out.println("Error: " + e);
        }
        return personal;
    }
}