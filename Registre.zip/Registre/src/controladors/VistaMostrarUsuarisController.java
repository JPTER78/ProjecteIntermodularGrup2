package controladors;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import objectes.Llista;
import objectes.Usuari;

public class VistaMostrarUsuarisController implements Initializable {
	
	@FXML private VBox root;
	@FXML private VBox vBoxMostrar;
	@FXML private Button botoEixir;
	
	public void eixirMostrarUsuaris (ActionEvent e) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/vistes/VistaAplicacioBase.fxml"));
			Scene escena = new Scene(root);
			Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
			Usuari usuariApp = (Usuari) window.getUserData();
			window.setScene(escena);
			window.setUserData(usuariApp);
			window.setTitle("MovieRater");
			window.show();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		Platform.runLater(() -> {
			Stage window = (Stage) root.getScene().getWindow();
			Usuari usuariApp = (Usuari) window.getUserData();
			try {
				Class.forName("org.mariadb.jdbc.Driver");

				String urlBaseDades = "jdbc:mysql://localhost:3306/Equip2PI";
				String usuari = "root";
				String contrasenya = "";

				Connection c = DriverManager.getConnection(urlBaseDades, usuari, contrasenya);
				Statement s = c.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
				ResultSet r = s.executeQuery("SELECT * FROM Usuari");

				while (r.next()) {
					Label nom = new Label(r.getString("Nom"));
					Label cognom = new Label(r.getString("Cognom"));
					Label email = new Label(r.getString("Email"));
					Label poblacio = new Label(r.getString("Poblacio"));
					Button botoMostrar = new Button();
					botoMostrar.setText("Llista Personal " + r.getInt("IDUsuari"));
					botoMostrar.setOnAction(new EventHandler<ActionEvent>() {
						public void handle(ActionEvent event) {
							try {
								int idLlista = Integer.parseInt(((Button) event.getSource()).getText().split(" ")[2]);
								int idUser = usuariApp.getIdUsuari();
								
								Llista llista = new Llista(idLlista, idUser);
								
								Parent root1 = FXMLLoader.load(getClass().getResource("/vistes/VistaMostrarLlistaPersonal.fxml"));
								Scene escena = new Scene(root1);
								Stage window = (Stage) root.getScene().getWindow();
								window.setScene(escena);
								window.setUserData(llista);
								window.setTitle("Llista Personal");
								window.show();
							} catch (Exception e2) {
								System.out.println("Error: " + e2);
							}
						}
					});
					Button botoMissatge = new Button();
					botoMissatge.setText("Enviar missatge");
					botoMissatge.setOnAction(new EventHandler<ActionEvent>() {
						public void handle(ActionEvent event) {
							try {
								int idUserRebre = Integer.parseInt(botoMostrar.getText().split(" ")[2]);
								int idUserEnviar = usuariApp.getIdUsuari();
								
								Llista missatge = new Llista(idUserRebre, idUserEnviar);
								
								Parent root1 = FXMLLoader.load(getClass().getResource("/vistes/VistaEnviarMissatge.fxml"));
								Scene escena = new Scene(root1);
								Stage window = (Stage) root.getScene().getWindow();
								window.setScene(escena);
								window.setUserData(missatge);
								window.setTitle("Enviar Missatge");
								window.show();
							} catch (Exception e2) {
								System.out.println("Error: " + e2);
							}
						}
					});
					
					nom.setPadding(new Insets(10, 10, 10, 10));
					cognom.setPadding(new Insets(10, 10, 10, 10));
					email.setPadding(new Insets(10, 10, 10, 10));
					poblacio.setPadding(new Insets(10, 10, 10, 10));
					botoMostrar.setPadding(new Insets(10, 10, 10, 10));
					botoMissatge.setPadding(new Insets(10, 10, 10, 10));
					HBox hBoxPelicula = new HBox(nom, cognom, email, poblacio, botoMostrar, botoMissatge);
					hBoxPelicula.setAlignment(Pos.CENTER);
					vBoxMostrar.getChildren().add(hBoxPelicula);
				}
			} catch (Exception e2) {
				System.out.println("Error: " + e2);
			}
		});
	}
	
}