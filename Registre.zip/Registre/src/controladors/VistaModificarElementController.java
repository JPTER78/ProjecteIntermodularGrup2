package controladors;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import objectes.Pelicula;
import objectes.Serie;
import objectes.Usuari;

public class VistaModificarElementController implements Initializable {
	
	@FXML private VBox root;
	@FXML private VBox vBoxMostrar;
	@FXML private Button botoEixir;
	
	public void eixirModificarElement (ActionEvent e) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/vistes/VistaAplicacioBase.fxml"));
			Scene escena = new Scene(root);
			Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
			window.setScene(escena);
			window.setTitle("MovieRater");
			window.show();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		Platform.runLater(() -> {
			Stage window = (Stage) root.getScene().getWindow();
			Usuari usuariApp = (Usuari) window.getUserData();
			try {
				Class.forName("org.mariadb.jdbc.Driver");
				
				String urlBaseDades = "jdbc:mysql://localhost:3306/Equip2PI";
				String usuari = "root";
				String contrasenya = "";
				
				Connection c = DriverManager.getConnection(urlBaseDades, usuari, contrasenya);
				Statement s = c.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
				ResultSet r = s.executeQuery("SELECT * FROM Peliculas");
				
				while (r.next()) {
					if (usuariApp.getIdUsuari() == r.getInt("IDUsuario")) {
						Label pelicula = new Label("Pelicula");
						Label nom = new Label(r.getString("NomPeli"));
						Label any = new Label(r.getString("Any"));
						Button botoModificar = new Button();
						botoModificar.setText("Modificar " + r.getInt("IDPeli"));
						botoModificar.setOnAction(new EventHandler<ActionEvent>() {
							public void handle(ActionEvent event) {
					            try {
					            	String idPelicula = ((Button) event.getSource()).getText().split(" ")[1];
					            	ResultSet r3 = s.executeQuery("SELECT * FROM Peliculas WHERE IDPeli = " + idPelicula);
					            	r3.next();
					            	Pelicula pelicula = new Pelicula(r3.getInt("IDPeli"), r3.getString("NomPeli"), r3.getString("Genere"), r3.getInt("Nota"), r3.getInt("Any"), r3.getInt("Durada"), r3.getString("Interprets"), r3.getString("Direccio"), r3.getString("Sinopsi"), r3.getInt("IDUsuario"));
					            	Parent root1 = FXMLLoader.load(getClass().getResource("/vistes/VistaModificarPelicula.fxml"));
					    			Scene escena = new Scene(root1);
					    			Stage window = (Stage) root.getScene().getWindow();
					    			window.setScene(escena);
					    			window.setUserData(pelicula);
					    			window.setTitle("Modificar Pelicula");
					    			window.show();
					            } catch (Exception e2) {
					       			System.out.println("Error: " + e2);
					            }
					        }
					    });
						pelicula.setPadding(new Insets(10,10,10,10));
						nom.setPadding(new Insets(10,10,10,10));
						any.setPadding(new Insets(10,10,10,10));
						HBox hBoxPelicula = new HBox(pelicula, nom, any, botoModificar);
						hBoxPelicula.setAlignment(Pos.CENTER);
						vBoxMostrar.getChildren().add(hBoxPelicula);
					}
				}
				ResultSet r2 = s.executeQuery("SELECT * FROM Series");
				while (r2.next()) {
					if (usuariApp.getIdUsuari() == r2.getInt("IDUsuario")) {
						Label serie = new Label("Serie");
						Label nom = new Label(r2.getString("NomSerie"));
						Label any = new Label(r2.getString("Any"));
						Button botoModificar = new Button();
						botoModificar.setText("Modificar " + r2.getInt("IDSerie"));
						botoModificar.setOnAction(new EventHandler<ActionEvent>() { 
							public void handle(ActionEvent event) {
					            try {
					            	String idSerie = ((Button) event.getSource()).getText().split(" ")[1];
					            	ResultSet r4 = s.executeQuery("SELECT * FROM Series WHERE IDSerie = " + idSerie);
					            	r4.next();
					            	Serie serie = new Serie(r4.getInt("IDSerie"), r4.getString("NomSerie"), r4.getInt("Temporades"), r4.getInt("Any"), r4.getString("Genere"), r4.getInt("Durada"), r4.getString("Interprets"), r4.getString("Direccio"), r4.getString("Sinopsi"), r4.getInt("Nota"), r4.getInt("IDUsuario"));
					            	Parent root1 = FXMLLoader.load(getClass().getResource("/vistes/VistaModificarSerie.fxml"));
					    			Scene escena = new Scene(root1);
					    			Stage window = (Stage) root.getScene().getWindow();
					    			window.setScene(escena);
					    			window.setUserData(serie);
					    			window.setTitle("Modificar Serie");
					    			window.show();
					            } catch (Exception e2) {
					       			System.out.println("Error: " + e2);
					            }
					        }
						});
						serie.setPadding(new Insets(10,10,10,10));
						nom.setPadding(new Insets(10,10,10,10));
						any.setPadding(new Insets(10,10,10,10));
						HBox hBoxSeries = new HBox(serie, nom, any, botoModificar);
						hBoxSeries.setAlignment(Pos.CENTER);
						vBoxMostrar.getChildren().add(hBoxSeries);
					}
				}
			} catch (Exception e2) {
				System.out.println("Error: " + e2);
			}
		});
	}
	
}