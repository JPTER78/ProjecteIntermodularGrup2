package objectes;

public class Llista {
	
	private int idLlista;
	private int idUser;
	
	public Llista(int idLlista, int idUser) {
		super();
		this.idLlista = idLlista;
		this.idUser = idUser;
	}
	
	public int getIdLlista() {
		return idLlista;
	}
	public void setIdLlista(int idLlista) {
		this.idLlista = idLlista;
	}
	public int getIdUser() {
		return idUser;
	}
	public void setIdUser(int idUser) {
		this.idUser = idUser;
	}
	
}