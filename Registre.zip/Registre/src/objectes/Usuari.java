package objectes;

import javafx.scene.image.Image;

public class Usuari {
	
	private int idUsuari;
	private String nomUsuari;
	private String cognomsUsuari;
	private String correuUsuari;
	private String contrasenyaUsuari;
	private String dataNaixementUsuari;
	private String poblacioUsuari;
	//private Image imatgeUsuari;
	
	public Usuari(int idUsuari, String nomUsuari, String cognomsUsuari, String correuUsuari, String contrasenyaUsuari,
			String dataNaixementUsuari, String poblacioUsuari) {
		super();
		this.idUsuari = idUsuari;
		this.nomUsuari = nomUsuari;
		this.cognomsUsuari = cognomsUsuari;
		this.correuUsuari = correuUsuari;
		this.contrasenyaUsuari = contrasenyaUsuari;
		this.dataNaixementUsuari = dataNaixementUsuari;
		this.poblacioUsuari = poblacioUsuari;
	}
	
	public int getIdUsuari() {
		return idUsuari;
	}
	public void setIdUsuari(int idUsuari) {
		this.idUsuari = idUsuari;
	}
	public String getNomUsuari() {
		return nomUsuari;
	}
	public void setNomUsuari(String nomUsuari) {
		this.nomUsuari = nomUsuari;
	}
	public String getCognomsUsuari() {
		return cognomsUsuari;
	}
	public void setCognomsUsuari(String cognomsUsuari) {
		this.cognomsUsuari = cognomsUsuari;
	}
	public String getCorreuUsuari() {
		return correuUsuari;
	}
	public void setCorreuUsuari(String correuUsuari) {
		this.correuUsuari = correuUsuari;
	}
	public String getContrasenyaUsuari() {
		return contrasenyaUsuari;
	}
	public void setContrasenyaUsuari(String contrasenyaUsuari) {
		this.contrasenyaUsuari = contrasenyaUsuari;
	}
	public String getDataNaixementUsuari() {
		return dataNaixementUsuari;
	}
	public void setDataNaixementUsuari(String dataNaixementUsuari) {
		this.dataNaixementUsuari = dataNaixementUsuari;
	}
	public String getPoblacioUsuari() {
		return poblacioUsuari;
	}
	public void setPoblacioUsuari(String poblacioUsuari) {
		this.poblacioUsuari = poblacioUsuari;
	}
	
}