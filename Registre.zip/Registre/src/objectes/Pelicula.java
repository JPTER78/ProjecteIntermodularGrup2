package objectes;

import javafx.scene.image.Image;

public class Pelicula {
	
	private int id;
	private String nom;
	private String genere;
	private int nota;
	private int any;
	private int durada;
	private String interprets;
	private String direccio;
	private String sinopsi;
	private int idUser;
	//private Image imatge;
	
	public Pelicula(int id, String nom, String genere, int nota, int any, int durada, String interprets, String direccio,
			String sinopsi, int idUser) {
		super();
		this.id = id;
		this.nom = nom;
		this.genere = genere;
		this.nota = nota;
		this.any = any;
		this.durada = durada;
		this.interprets = interprets;
		this.direccio = direccio;
		this.sinopsi = sinopsi;
		this.idUser = idUser;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getGenere() {
		return genere;
	}
	public void setGenere(String genere) {
		this.genere = genere;
	}
	public int getNota() {
		return nota;
	}
	public void setNota(int nota) {
		this.nota = nota;
	}
	public int getAny() {
		return any;
	}
	public void setAny(int any) {
		this.any = any;
	}
	public int getDurada() {
		return durada;
	}
	public void setDurada(int durada) {
		this.durada = durada;
	}
	public String getInterprets() {
		return interprets;
	}
	public void setInterprets(String interprets) {
		this.interprets = interprets;
	}
	public String getDireccio() {
		return direccio;
	}
	public void setDireccio(String direccio) {
		this.direccio = direccio;
	}
	public String getSinopsi() {
		return sinopsi;
	}
	public void setSinopsi(String sinopsi) {
		this.sinopsi = sinopsi;
	}
	public int getIdUser() {
		return idUser;
	}
	public void setIdUser(int idUser) {
		this.idUser = idUser;
	}
	
}