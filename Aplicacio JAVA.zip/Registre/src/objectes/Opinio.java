package objectes;

public class Opinio {

	private int tipus;
	private int idElement;
	private int idUsuari;
	
	public Opinio(int tipus, int idElement, int idUsuari) {
		super();
		this.tipus = tipus;
		this.idElement = idElement;
		this.idUsuari = idUsuari;
	}
	
	public int getTipus() {
		return tipus;
	}
	public void setTipus(int tipus) {
		this.tipus = tipus;
	}
	public int getIdElement() {
		return idElement;
	}
	public void setIdElement(int idElement) {
		this.idElement = idElement;
	}
	public int getIdUsuari() {
		return idUsuari;
	}
	public void setIdUsuari(int idUsuari) {
		this.idUsuari = idUsuari;
	}
	
}