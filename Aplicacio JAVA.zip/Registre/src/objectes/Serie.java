package objectes;

import javafx.scene.image.Image;

public class Serie {
	
	private int id;
	private String nom;
	private int temporades;
	private int any;
	private String genere;
	private int durada;
	private String interprets;
	private String direccio;
	private String sinopsi;
	private int nota;
	private int idUser;
	//private Image imatge;
	
	public Serie(int id, String nom, int temporades, int any, String genere, int durada, String interprets,
			String direccio, String sinopsi, int nota, int idUser) {
		super();
		this.id = id;
		this.nom = nom;
		this.temporades = temporades;
		this.any = any;
		this.genere = genere;
		this.durada = durada;
		this.interprets = interprets;
		this.direccio = direccio;
		this.sinopsi = sinopsi;
		this.nota = nota;
		this.idUser = idUser;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public int getTemporades() {
		return temporades;
	}
	public void setTemporades(int temporades) {
		this.temporades = temporades;
	}
	public int getAny() {
		return any;
	}
	public void setAny(int any) {
		this.any = any;
	}
	public String getGenere() {
		return genere;
	}
	public void setGenere(String genere) {
		this.genere = genere;
	}
	public int getDurada() {
		return durada;
	}
	public void setDurada(int durada) {
		this.durada = durada;
	}
	public String getInterprets() {
		return interprets;
	}
	public void setInterprets(String interprets) {
		this.interprets = interprets;
	}
	public String getDireccio() {
		return direccio;
	}
	public void setDireccio(String direccio) {
		this.direccio = direccio;
	}
	public String getSinopsi() {
		return sinopsi;
	}
	public void setSinopsi(String sinopsi) {
		this.sinopsi = sinopsi;
	}
	public int getNota() {
		return nota;
	}
	public void setNota(int nota) {
		this.nota = nota;
	}
	public int getIdUser() {
		return idUser;
	}
	public void setIdUser(int idUser) {
		this.idUser = idUser;
	}
	
}