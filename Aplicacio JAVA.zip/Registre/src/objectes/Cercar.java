package objectes;

public class Cercar {
	
	private String pelicula;
	private String serie;
	private String nom;
	private int idUser;
	
	public Cercar(String pelicula, String serie, String nom, int idUser) {
		super();
		this.pelicula = pelicula;
		this.serie = serie;
		this.nom = nom;
		this.idUser = idUser;
	}
	
	public String getPelicula() {
		return pelicula;
	}
	public void setPelicula(String pelicula) {
		this.pelicula = pelicula;
	}
	public String getSerie() {
		return serie;
	}
	public void setSerie(String serie) {
		this.serie = serie;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public int getIdUser() {
		return idUser;
	}
	public void setIdUser(int idUser) {
		this.idUser = idUser;
	}
	
}