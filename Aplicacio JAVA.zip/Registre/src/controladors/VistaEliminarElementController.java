package controladors;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import objectes.Usuari;

public class VistaEliminarElementController implements Initializable {
	
	@FXML private VBox root;
	@FXML private VBox vBoxMostrar;
	@FXML private Button botoEixir;
	
	public void eixirEliminarElement (ActionEvent e) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/vistes/VistaAplicacioBase.fxml"));
			Scene escena = new Scene(root);
			Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
			window.setScene(escena);
			window.setTitle("MovieRater");
			window.show();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		Platform.runLater(() -> {
			Stage window = (Stage) root.getScene().getWindow();
			Usuari usuariApp = (Usuari) window.getUserData();
			try {
				Class.forName("org.mariadb.jdbc.Driver");
				
				String urlBaseDades = "jdbc:mysql://localhost:3306/Equip2PI";
				String usuari = "root";
				String contrasenya = "";
				
				Connection c = DriverManager.getConnection(urlBaseDades, usuari, contrasenya);
				Statement s = c.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
				ResultSet r = s.executeQuery("SELECT * FROM Peliculas");
				
				while (r.next()) {
					if (usuariApp.getIdUsuari() == r.getInt("IDUsuario")) {
						Label pelicula = new Label("Pelicula");
						Label nom = new Label(r.getString("NomPeli"));
						Label any = new Label(r.getString("Any"));
						Button botoEliminar = new Button();
						botoEliminar.setText("Eliminar " + r.getInt("IDPeli"));
						botoEliminar.setOnAction(new EventHandler<ActionEvent>() {
		    				@Override
		    				public void handle (ActionEvent e) {
		    					try {
		    						String id = botoEliminar.getText().split(" ")[1];
			    					Alert alert = new Alert(AlertType.CONFIRMATION);
			    					alert.setTitle("Confirmació");
			    				    alert.setWidth(200);
			    				    alert.setHeaderText(null);
			    				    alert.setContentText("Segur que vols eliminar la Película?");
			    				    alert.setResizable(true);
			    				    alert.getDialogPane().setPrefSize(250, 200);
			    				    alert.showAndWait();
			    				    if (alert.getResult().getText().equals("OK")) {
			    				    	s.executeUpdate("DELETE FROM Peliculas WHERE IDPeli = " + id);
					       				vBoxMostrar.getChildren().remove(botoEliminar.getParent());
			    				    } else if (alert.getResult().getText().equals("Cancel")) {
			    				    	System.out.println("Cancel");
			    				    } else {
			    				    	System.out.println("Error");
			    				    }
								} catch (Exception e2) {
									System.out.println("Error: " + e2);
								}
		    					
		    				}
		    			});
						pelicula.setPadding(new Insets(10,10,10,10));
						nom.setPadding(new Insets(10,10,10,10));
						any.setPadding(new Insets(10,10,10,10));
						HBox hBoxPelicula = new HBox(pelicula, nom, any, botoEliminar);
						hBoxPelicula.setAlignment(Pos.CENTER);
//						hBoxPelicula.setPadding(new Insets(10,10,10,10));
						vBoxMostrar.getChildren().add(hBoxPelicula);
					}
				}
				ResultSet r2 = s.executeQuery("SELECT * FROM Series");
				while (r2.next()) {
					if (usuariApp.getIdUsuari() == r2.getInt("IDUsuario")) {
						Label serie = new Label("Serie");
						Label nom = new Label(r2.getString("NomSerie"));
						Label any = new Label(r2.getString("Any"));
						Button botoEliminar = new Button();
						botoEliminar.setText("Eliminar " + r2.getInt("IDSerie"));
						botoEliminar.setOnAction(new EventHandler<ActionEvent>() { 
							public void handle (ActionEvent e) {
		    					try {
		    						String id = botoEliminar.getText().split(" ")[1];
			    					Alert alert = new Alert(AlertType.CONFIRMATION);
			    					alert.setTitle("Confirmació");
			    				    alert.setWidth(200);
			    				    alert.setHeaderText(null);
			    				    alert.setContentText("Segur que vols eliminar la Sèrie?");
			    				    alert.setResizable(true);
			    				    alert.getDialogPane().setPrefSize(250, 200);
			    				    alert.showAndWait();
			    				    if (alert.getResult().getText().equals("OK")) {
			    				    	s.executeUpdate("DELETE FROM Series WHERE IDSerie = " + id);
					       				vBoxMostrar.getChildren().remove(botoEliminar.getParent());
			    				    } else if (alert.getResult().getText().equals("Cancel")) {
			    				    	System.out.println("Cancel");
			    				    } else {
			    				    	System.out.println("Error");
			    				    }
								} catch (Exception e2) {
									System.out.println("Error: " + e2);
								}
		    					
		    				}
						});
						serie.setPadding(new Insets(10,10,10,10));
						nom.setPadding(new Insets(10,10,10,10));
						any.setPadding(new Insets(10,10,10,10));
						HBox hBoxSeries = new HBox(serie, nom, any, botoEliminar);
						hBoxSeries.setAlignment(Pos.CENTER);
//						hBoxSeries.setPadding(new Insets(10,10,10,10));
						vBoxMostrar.getChildren().add(hBoxSeries);
					}
				}
			} catch (Exception e2) {
				System.out.println("Error: " + e2);
			}
		});
	}
	
}