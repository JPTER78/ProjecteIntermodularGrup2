package controladors;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import objectes.Llista;
import objectes.Usuari;

public class VistaEnviarMissatgeController implements Initializable {
	
	@FXML private VBox root;
	@FXML private Label missatge;
	@FXML private TextField titol;
	@FXML private TextArea contingut;
	@FXML private Button botoEixir;
	@FXML private Button botoBorrarDades;
	@FXML private Button botoLogear;
	@FXML private Label error;
	
	public void eixirMissatge (ActionEvent e) {
		try {
			Class.forName("org.mariadb.jdbc.Driver");
			
			String urlBaseDades = "jdbc:mysql://localhost:3306/Equip2PI";
			String usuari = "root";
			String contrasenya = "";
			
			Connection c = DriverManager.getConnection(urlBaseDades, usuari, contrasenya);
			Statement s = c.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
			ResultSet r = s.executeQuery("SELECT * FROM Usuari");
			Usuari usuariApp = new Usuari(0, null, null, null, null, null, null);
			Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
			Llista llista = (Llista) window.getUserData();
			
			while (r.next()) {
				if (r.getInt("IDUsuari") == llista.getIdUser()) {
					usuariApp.setIdUsuari(r.getInt("IDUsuari"));
					usuariApp.setNomUsuari(r.getString("Nom"));
					usuariApp.setCognomsUsuari(r.getString("Cognom"));
					usuariApp.setCorreuUsuari(r.getString("Email"));
					usuariApp.setContrasenyaUsuari(r.getString("Contrasenya"));
					usuariApp.setDataNaixementUsuari(r.getString("DataNaixement"));
					usuariApp.setPoblacioUsuari(r.getString("Poblacio"));
				}
			}
			
			Parent root = FXMLLoader.load(getClass().getResource("/vistes/VistaMostrarUsuaris.fxml"));
			Scene escena = new Scene(root);
			window.setScene(escena);
			window.setUserData(usuariApp);
			window.setTitle("Mostrar Usuaris");
			window.show();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}
	
	public void esborrarDades (ActionEvent e) {
		titol.setText("");
		contingut.setText("");
		error.setText("");
	}
	
	public void enviarMissatge (ActionEvent e) {
		Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
		Llista llista = (Llista) window.getUserData();
		String titolMissatge = titol.getText().trim();
        String contingutMissatge = contingut.getText().trim();
        String nomTaulaEnviar = "";
        String nomTaulaRebut = "";
        
        if (titolMissatge.isEmpty() || contingutMissatge.isEmpty()) {
        	error.setStyle("-fx-text-fill: red;");
			error.setText("No pots deixar camps en blanc");
        } else {
        	try {
            	Class.forName("org.mariadb.jdbc.Driver");
    			
    			String urlBaseDades = "jdbc:mysql://localhost:3306/Equip2PI";
    			String usuari = "root";
    			String contrasenya = "";
    			
    			Connection c = DriverManager.getConnection(urlBaseDades, usuari, contrasenya);
    			Statement s = c.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
    			ResultSet r = s.executeQuery("SELECT * FROM Usuari");
    			
    			while (r.next()) {
    				if (r.getInt("IDUsuari") == llista.getIdUser()) {
    					nomTaulaEnviar = r.getString("Email").split("@")[0] + "MissatgesEnviats";
    				} else if (r.getInt("IDUsuari") == llista.getIdLlista()) {
    					nomTaulaRebut = r.getString("Email").split("@")[0] + "MissatgesRebuts";
    				}
    			}
    			
    			s.executeUpdate("INSERT INTO " + nomTaulaEnviar + " (idEnviar, idRebre, titolMissatge, contingutMissatge, llegit) VALUES (" + llista.getIdUser() + ", " + llista.getIdLlista() + ", '" + titolMissatge + "', '" + contingutMissatge + "', 0)");
    			s.executeUpdate("INSERT INTO " + nomTaulaRebut + " (idEnviar, idRebre, titolMissatge, contingutMissatge, llegit) VALUES (" + llista.getIdUser() + ", " + llista.getIdLlista() + ", '" + titolMissatge + "', '" + contingutMissatge + "', 0)");
    			error.setStyle("-fx-text-fill: green;");
    			error.setText("Missatge enviat satisfactoriament");
    		} catch (Exception e2) {
    			System.out.println("Error: " + e2);
    		}
        }
	}
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		Platform.runLater(() -> {
			try {
				Class.forName("org.mariadb.jdbc.Driver");

				String urlBaseDades = "jdbc:mysql://localhost:3306/Equip2PI";
				String usuari = "root";
				String contrasenya = "";

				Connection c = DriverManager.getConnection(urlBaseDades, usuari, contrasenya);
				Statement s = c.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
				ResultSet r = s.executeQuery("SELECT * FROM Usuari");
				Stage window = (Stage) root.getScene().getWindow();
				Llista llista = (Llista) window.getUserData();
				String nomUsuari = "";

				while (r.next()) {
					if (r.getInt("IDUsuari") == llista.getIdLlista()) {
						nomUsuari = r.getString("Nom");
					}
				}
				missatge.setText("Enviar missatge a " + nomUsuari);
			} catch (Exception e) {

			}
		});
	}
	
}