package controladors;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import objectes.Usuari;

public class VistaExportarElementsController {
	
	@FXML private VBox root;
	@FXML private Button botoEixir;
	@FXML private Button botoBorrarDades;
	@FXML private Button botoExportar;
	@FXML private CheckBox peliculesCB;
	@FXML private CheckBox seriesCB;
	@FXML private RadioButton botoPersonal;
	@FXML private RadioButton botoGeneral;
	@FXML private Label error;
	
	public void eixirLogin (ActionEvent e) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/vistes/VistaAplicacioBase.fxml"));
			Scene escena = new Scene(root);
			Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
			window.setScene(escena);
			window.setTitle("MovieRater");
			window.show();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	
	public void esborrarDades (ActionEvent e) {
        peliculesCB.setSelected(false);
        seriesCB.setSelected(false);
        botoPersonal.setSelected(false);
        botoGeneral.setSelected(false);
        error.setText("");
	}
	
	public void exportarLlista (ActionEvent e) {
		Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
		Usuari usuariApp = (Usuari) window.getUserData();
		if (botoPersonal.isSelected()) {
			try {
				Class.forName("org.mariadb.jdbc.Driver");
				
				String urlBaseDades = "jdbc:mysql://localhost:3306/Equip2PI";
				String usuariBD = "root";
				String contrasenyaBD = "";
				
				Connection c = DriverManager.getConnection(urlBaseDades, usuariBD, contrasenyaBD);
				Statement s = c.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
				
	    		if (peliculesCB.isSelected() && seriesCB.isSelected()) {
	    			ResultSet r1 = s.executeQuery("SELECT * FROM Peliculas");
    				crearCarpeta(usuariApp);
    				File file = crearFilePersonal(usuariApp);
    				file.createNewFile();
					while (r1.next()) {
		    			String id = r1.getString("IDPeli");
		    			String nom = r1.getString("NomPeli");
		    			String genere = r1.getString("Genere");
		    			String nota = r1.getString("Nota");
		    			String any = r1.getString("Any");
		    			String durada = r1.getString("Durada");
		    			String interprets = r1.getString("Interprets");
		    			String direccio = r1.getString("Direccio");
		    			String sinopsi = r1.getString("Sinopsi");
		    			String tipus = r1.getString("TipusElement");
		    			
		    			String pelicula = "=================\n"
		    							+ "Película #" + id + "\n"
		    							+ "=================\n"
		    							+ "Nombre: " + nom + "\n"
		    							+ "Any: " + any + "\n"
		    							+ "Durada: " + durada + "\n"
		    							+ "Genere: " + genere + "\n"
		    							+ "Sinopsi: " + sinopsi + "\n"
		    							+ "Direcció: " + direccio + "\n"
		    							+ "Intérprets: " + interprets + "\n"
		    							+ "Nota: " + nota + "\n\n";
		    			
		    			if (tipus.matches("Personal")) {
			    			BufferedWriter bw = new BufferedWriter(new FileWriter(file, true));
			    			bw.write(pelicula);
			    			bw.close();
		    			}
		    		}
		    		ResultSet r2 = s.executeQuery("SELECT * FROM Series");
					while (r2.next()) {
						String id = r2.getString("IDSerie");
		    			String nom = r2.getString("NomSerie");
		    			String temporades = r2.getString("NomSerie");
		    			String genere = r2.getString("Genere");
		    			String nota = r2.getString("Nota");
		    			String any = r2.getString("Any");
		    			String durada = r2.getString("Durada");
		    			String interprets = r2.getString("Interprets");
		    			String direccio = r2.getString("Direccio");
		    			String sinopsi = r2.getString("Sinopsi");
		    			String tipus = r2.getString("TipusElement");
		    			
		    			String serie = "=================\n"
    							+ "Sèrie #" + id + "\n"
    							+ "=================\n"
    							+ "Nombre: " + nom + "\n"
    							+ "Any: " + any + "\n"
    	    					+ "Temporades: " + temporades + "\n"
    							+ "Durada: " + durada + "\n"
    							+ "Genere: " + genere + "\n"
    							+ "Sinopsi: " + sinopsi + "\n"
    							+ "Direcció: " + direccio + "\n"
    							+ "Intérprets: " + interprets + "\n"
    							+ "Nota: " + nota + "\n\n";
    			
		    			if (tipus.matches("Personal")) {
		    				BufferedWriter bw = new BufferedWriter(new FileWriter(file, true));
		    				bw.write(serie);
		    				bw.close();
		    			}
		    		}
					error.setStyle("-fx-text-fill: green;");
					error.setText("Pelicules i Series exportades satisfactoriament");
				} else if (peliculesCB.isSelected()) {
	    			ResultSet r1 = s.executeQuery("SELECT * FROM Peliculas");
    				crearCarpeta(usuariApp);
    				File file = crearFilePersonal(usuariApp);
    				file.createNewFile();
					while (r1.next()) {
		    			String id = r1.getString("IDPeli");
		    			String nom = r1.getString("NomPeli");
		    			String genere = r1.getString("Genere");
		    			String nota = r1.getString("Nota");
		    			String any = r1.getString("Any");
		    			String durada = r1.getString("Durada");
		    			String interprets = r1.getString("Interprets");
		    			String direccio = r1.getString("Direccio");
		    			String sinopsi = r1.getString("Sinopsi");
		    			String tipus = r1.getString("TipusElement");
		    			
		    			String pelicula = "=================\n"
		    							+ "Película #" + id + "\n"
		    							+ "=================\n"
		    							+ "Nombre: " + nom + "\n"
		    							+ "Any: " + any + "\n"
		    							+ "Durada: " + durada + "\n"
		    							+ "Genere: " + genere + "\n"
		    							+ "Sinopsi: " + sinopsi + "\n"
		    							+ "Direcció: " + direccio + "\n"
		    							+ "Intérprets: " + interprets + "\n"
		    							+ "Nota: " + nota + "\n\n";
		    			
		    			if (tipus.matches("Personal")) {
			    			BufferedWriter bw = new BufferedWriter(new FileWriter(file, true));
			    			bw.write(pelicula);
			    			bw.close();
		    			}
		    		}
					error.setStyle("-fx-text-fill: green;");
					error.setText("Pelicules exportades satisfactoriament");
				} else if (seriesCB.isSelected()) {
		    		ResultSet r2 = s.executeQuery("SELECT * FROM Series");
    				crearCarpeta(usuariApp);
    				File file = crearFilePersonal(usuariApp);
    				file.createNewFile();
					while (r2.next()) {
						String id = r2.getString("IDSerie");
		    			String nom = r2.getString("NomSerie");
		    			String temporades = r2.getString("NomSerie");
		    			String genere = r2.getString("Genere");
		    			String nota = r2.getString("Nota");
		    			String any = r2.getString("Any");
		    			String durada = r2.getString("Durada");
		    			String interprets = r2.getString("Interprets");
		    			String direccio = r2.getString("Direccio");
		    			String sinopsi = r2.getString("Sinopsi");
		    			String tipus = r2.getString("TipusElement");
		    			
		    			String serie = "=================\n"
    							+ "Sèrie #" + id + "\n"
    							+ "=================\n"
    							+ "Nombre: " + nom + "\n"
    							+ "Any: " + any + "\n"
    	    					+ "Temporades: " + temporades + "\n"
    							+ "Durada: " + durada + "\n"
    							+ "Genere: " + genere + "\n"
    							+ "Sinopsi: " + sinopsi + "\n"
    							+ "Direcció: " + direccio + "\n"
    							+ "Intérprets: " + interprets + "\n"
    							+ "Nota: " + nota + "\n\n";
    			
		    			if (tipus.matches("Personal")) {
		    				BufferedWriter bw = new BufferedWriter(new FileWriter(file, true));
		    				bw.write(serie);
		    				bw.close();
		    			}
		    		}
					error.setStyle("-fx-text-fill: green;");
					error.setText("Series exportades satisfactoriament");
				} else {
					error.setStyle("-fx-text-fill: red;");
					error.setText("Has d'elegir al menys un tipus d'element per a exportar");
				}
			} catch (Exception e2) {
				System.out.println("Error: " + e2);
			}
		} else if (botoGeneral.isSelected()) {
			try {
				Class.forName("org.mariadb.jdbc.Driver");
				
				String urlBaseDades = "jdbc:mysql://localhost:3306/Equip2PI";
				String usuariBD = "root";
				String contrasenyaBD = "";
				
				Connection c = DriverManager.getConnection(urlBaseDades, usuariBD, contrasenyaBD);
				Statement s = c.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
	    		
	    		if (peliculesCB.isSelected() && seriesCB.isSelected()) {
	    			ResultSet r1 = s.executeQuery("SELECT * FROM Peliculas");
    				crearCarpeta(usuariApp);
    				File file = crearFileGeneral(usuariApp);
    				file.createNewFile();
					while (r1.next()) {
		    			String id = r1.getString("IDPeli");
		    			String nom = r1.getString("NomPeli");
		    			String genere = r1.getString("Genere");
		    			String nota = r1.getString("Nota");
		    			String any = r1.getString("Any");
		    			String durada = r1.getString("Durada");
		    			String interprets = r1.getString("Interprets");
		    			String direccio = r1.getString("Direccio");
		    			String sinopsi = r1.getString("Sinopsi");
		    			String tipus = r1.getString("TipusElement");
		    			
		    			String pelicula = "=================\n"
		    							+ "Película #" + id + "\n"
		    							+ "=================\n"
		    							+ "Nombre: " + nom + "\n"
		    							+ "Any: " + any + "\n"
		    							+ "Durada: " + durada + "\n"
		    							+ "Genere: " + genere + "\n"
		    							+ "Sinopsi: " + sinopsi + "\n"
		    							+ "Direcció: " + direccio + "\n"
		    							+ "Intérprets: " + interprets + "\n"
		    							+ "Nota: " + nota + "\n\n";
		    			
		    			if (tipus.matches("General")) {
			    			BufferedWriter bw = new BufferedWriter(new FileWriter(file, true));
			    			bw.write(pelicula);
			    			bw.close();
		    			}
		    		}
		    		ResultSet r2 = s.executeQuery("SELECT * FROM Series");
					while (r2.next()) {
						String id = r2.getString("IDSerie");
		    			String nom = r2.getString("NomSerie");
		    			String temporades = r2.getString("NomSerie");
		    			String genere = r2.getString("Genere");
		    			String nota = r2.getString("Nota");
		    			String any = r2.getString("Any");
		    			String durada = r2.getString("Durada");
		    			String interprets = r2.getString("Interprets");
		    			String direccio = r2.getString("Direccio");
		    			String sinopsi = r2.getString("Sinopsi");
		    			String tipus = r2.getString("TipusElement");
		    			
		    			String serie = "=================\n"
    							+ "Sèrie #" + id + "\n"
    							+ "=================\n"
    							+ "Nombre: " + nom + "\n"
    							+ "Any: " + any + "\n"
    	    					+ "Temporades: " + temporades + "\n"
    							+ "Durada: " + durada + "\n"
    							+ "Genere: " + genere + "\n"
    							+ "Sinopsi: " + sinopsi + "\n"
    							+ "Direcció: " + direccio + "\n"
    							+ "Intérprets: " + interprets + "\n"
    							+ "Nota: " + nota + "\n\n";
    			
		    			if (tipus.matches("General")) {
		    				BufferedWriter bw = new BufferedWriter(new FileWriter(file, true));
		    				bw.write(serie);
		    				bw.close();
		    			}
		    		}
					error.setStyle("-fx-text-fill: green;");
					error.setText("Pelicules i Series exportades satisfactoriament");
				} else if (peliculesCB.isSelected()) {
	    			ResultSet r1 = s.executeQuery("SELECT * FROM Peliculas");
    				crearCarpeta(usuariApp);
    				File file = crearFileGeneral(usuariApp);
    				file.createNewFile();
					while (r1.next()) {
		    			String id = r1.getString("IDPeli");
		    			String nom = r1.getString("NomPeli");
		    			String genere = r1.getString("Genere");
		    			String nota = r1.getString("Nota");
		    			String any = r1.getString("Any");
		    			String durada = r1.getString("Durada");
		    			String interprets = r1.getString("Interprets");
		    			String direccio = r1.getString("Direccio");
		    			String sinopsi = r1.getString("Sinopsi");
		    			String tipus = r1.getString("TipusElement");
		    			
		    			String pelicula = "=================\n"
		    							+ "Película #" + id + "\n"
		    							+ "=================\n"
		    							+ "Nombre: " + nom + "\n"
		    							+ "Any: " + any + "\n"
		    							+ "Durada: " + durada + "\n"
		    							+ "Genere: " + genere + "\n"
		    							+ "Sinopsi: " + sinopsi + "\n"
		    							+ "Direcció: " + direccio + "\n"
		    							+ "Intérprets: " + interprets + "\n"
		    							+ "Nota: " + nota + "\n\n";
		    			
		    			if (tipus.matches("General")) {
			    			BufferedWriter bw = new BufferedWriter(new FileWriter(file, true));
			    			bw.write(pelicula);
			    			bw.close();
		    			}
		    		}
					error.setStyle("-fx-text-fill: green;");
					error.setText("Pelicules exportades satisfactoriament");
				} else if (seriesCB.isSelected()) {
		    		ResultSet r2 = s.executeQuery("SELECT * FROM Series");
    				crearCarpeta(usuariApp);
    				File file = crearFileGeneral(usuariApp);
    				file.createNewFile();
					while (r2.next()) {
						String id = r2.getString("IDSerie");
		    			String nom = r2.getString("NomSerie");
		    			String temporades = r2.getString("NomSerie");
		    			String genere = r2.getString("Genere");
		    			String nota = r2.getString("Nota");
		    			String any = r2.getString("Any");
		    			String durada = r2.getString("Durada");
		    			String interprets = r2.getString("Interprets");
		    			String direccio = r2.getString("Direccio");
		    			String sinopsi = r2.getString("Sinopsi");
		    			String tipus = r2.getString("TipusElement");
		    			
		    			String serie = "=================\n"
    							+ "Sèrie #" + id + "\n"
    							+ "=================\n"
    							+ "Nombre: " + nom + "\n"
    							+ "Any: " + any + "\n"
    	    					+ "Temporades: " + temporades + "\n"
    							+ "Durada: " + durada + "\n"
    							+ "Genere: " + genere + "\n"
    							+ "Sinopsi: " + sinopsi + "\n"
    							+ "Direcció: " + direccio + "\n"
    							+ "Intérprets: " + interprets + "\n"
    							+ "Nota: " + nota + "\n\n";
    			
		    			if (tipus.matches("General")) {
		    				BufferedWriter bw = new BufferedWriter(new FileWriter(file, true));
		    				bw.write(serie);
		    				bw.close();
		    			}
		    		}
					error.setStyle("-fx-text-fill: green;");
					error.setText("Series exportades satisfactoriament");
				} else {
					error.setStyle("-fx-text-fill: red;");
					error.setText("Has d'elegir al menys un tipus d'element per a exportar");
				}
			} catch (Exception e2) {
				System.out.println("Error: " + e2);
			}
		} else {
			error.setStyle("-fx-text-fill: red;");
			error.setText("Has d'elegir entre 'Personal' i 'General'");
		}
	}
	
	public File crearFilePersonal(Usuari usuariApp) {
		File file = null;
		Boolean fitxerPosible = false;
		String correuUser = usuariApp.getCorreuUsuari().split("@")[0];
		int contador = 1;

		while (!fitxerPosible) {
			file = new File("usuaris/" + correuUser + "/llistaPersonal" + contador + ".txt");
			if (file.exists()) {
				contador++;
			} else {
				fitxerPosible = true;
			}
		}
		return file;
	}
	
	public File crearFileGeneral(Usuari usuariApp) {
		File file = null;
		Boolean fitxerPosible = false;
		String correuUser = usuariApp.getCorreuUsuari().split("@")[0];
		int contador = 1;

		while (!fitxerPosible) {
			file = new File("usuaris/" + correuUser + "/llistaGeneral" + contador + ".txt");
			if (file.exists()) {
				contador++;
			} else {
				fitxerPosible = true;
			}
		}
		return file;
	}
	
	public void crearCarpeta(Usuari usuariApp) {
		String correuUser = usuariApp.getCorreuUsuari().split("@")[0];
		File carpetaUsuaris = new File("usuaris");
		if (!carpetaUsuaris.exists()) {
			carpetaUsuaris.mkdir();
		}
		File carpeta = new File("usuaris/" + correuUser);
		if (!carpeta.exists()) {
			carpeta.mkdir();
		}
	}
	
}