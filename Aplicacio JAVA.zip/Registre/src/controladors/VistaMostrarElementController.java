package controladors;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import objectes.Cercar;
import objectes.Usuari;

public class VistaMostrarElementController implements Initializable {
	
	@FXML private VBox root;
	@FXML private VBox vBoxMostrar;
	@FXML private Button botoEixir;
	
	public void eixirMostrarElement (ActionEvent e) {
		try {
			Class.forName("org.mariadb.jdbc.Driver");
			
			String urlBaseDades = "jdbc:mysql://localhost:3306/Equip2PI";
			String usuari = "root";
			String contrasenya = "";
			
			Connection c = DriverManager.getConnection(urlBaseDades, usuari, contrasenya);
			Statement s = c.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
			ResultSet r = s.executeQuery("SELECT * FROM Usuari");
			Usuari usuariApp = new Usuari(0, null, null, null, null, null, null);
			Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
			Cercar element = (Cercar) window.getUserData();
			
			while (r.next()) {
				if (r.getInt("IDUsuari") == element.getIdUser()) {
					usuariApp.setIdUsuari(r.getInt("IDUsuari"));
					usuariApp.setNomUsuari(r.getString("Nom"));
					usuariApp.setCognomsUsuari(r.getString("Cognom"));
					usuariApp.setCorreuUsuari(r.getString("Email"));
					usuariApp.setContrasenyaUsuari(r.getString("Contrasenya"));
					usuariApp.setDataNaixementUsuari(r.getString("DataNaixement"));
					usuariApp.setPoblacioUsuari(r.getString("Poblacio"));
				}
			}
			
			Parent root = FXMLLoader.load(getClass().getResource("/vistes/VistaCercarElement.fxml"));
			Scene escena = new Scene(root);
			window.setScene(escena);
			window.setUserData(usuariApp);
			window.setTitle("Cercar Element");
			window.show();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}
	
	public void mostrarPelicules(String nomPelicula) {
		try {
			Class.forName("org.mariadb.jdbc.Driver");
			
			String urlBaseDades = "jdbc:mysql://localhost:3306/Equip2PI";
			String usuari = "root";
			String contrasenya = "";
			
			Connection c = DriverManager.getConnection(urlBaseDades, usuari, contrasenya);
			Statement s = c.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
			ResultSet r2 = s.executeQuery("SELECT * FROM Peliculas");
			while (r2.next()) {
				if (r2.getString("NomPeli").equals(nomPelicula)) {
					Label serie = new Label("Pel·lícula");
					Label nom = new Label(r2.getString("NomPeli"));
					Label any = new Label(r2.getString("Any"));
					Label durada = new Label(r2.getString("Durada"));
					serie.setPadding(new Insets(10,10,10,10));
					nom.setPadding(new Insets(10,10,10,10));
					any.setPadding(new Insets(10,10,10,10));
					durada.setPadding(new Insets(10,10,10,10));
					HBox hBoxSeries = new HBox(serie, nom, any, durada);
					hBoxSeries.setAlignment(Pos.CENTER);
					vBoxMostrar.getChildren().add(hBoxSeries);
				}
			}
		} catch (Exception e2) {
			System.out.println("Error: " + e2);
		}
	}
	
	public void mostrarSeries(String nomSerie) {
		try {
			Class.forName("org.mariadb.jdbc.Driver");
			
			String urlBaseDades = "jdbc:mysql://localhost:3306/Equip2PI";
			String usuari = "root";
			String contrasenya = "";
			
			Connection c = DriverManager.getConnection(urlBaseDades, usuari, contrasenya);
			Statement s = c.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
			ResultSet r2 = s.executeQuery("SELECT * FROM Series");
			while (r2.next()) {
				if (r2.getString("NomSerie").equals(nomSerie)) {
					Label serie = new Label("Sèrie");
					Label nom = new Label(r2.getString("NomSerie"));
					Label any = new Label(r2.getString("Any"));
					Label temporades = new Label(r2.getString("Temporades"));
					Label durada = new Label(r2.getString("Durada"));
					serie.setPadding(new Insets(10,10,10,10));
					nom.setPadding(new Insets(10,10,10,10));
					any.setPadding(new Insets(10,10,10,10));
					temporades.setPadding(new Insets(10,10,10,10));
					durada.setPadding(new Insets(10,10,10,10));
					HBox hBoxSeries = new HBox(serie, nom, any, temporades, durada);
					hBoxSeries.setAlignment(Pos.CENTER);
					vBoxMostrar.getChildren().add(hBoxSeries);
				}
			}
		} catch (Exception e2) {
			System.out.println("Error: " + e2);
		}
	}
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		Platform.runLater(() -> {
			Stage window = (Stage) root.getScene().getWindow();
			Cercar element = (Cercar) window.getUserData();
			
			if (element.getPelicula().equals("SI")) {
				mostrarPelicules(element.getNom());
			}
			
			if (element.getSerie().equals("SI")) {
				mostrarSeries(element.getNom());
			}
		});
	}
	
}