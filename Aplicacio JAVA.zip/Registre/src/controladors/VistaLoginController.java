package controladors;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import org.mindrot.jbcrypt.BCrypt;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import objectes.Usuari;

public class VistaLoginController {
	
	@FXML private VBox root;
	@FXML private Button botoEixir;
	@FXML private Button botoBorrarDades;
	@FXML private Button botoLogear;
	@FXML private TextField correu;
	@FXML private PasswordField contrasenya;
	@FXML private Label error;
	
	public void eixirLogin (ActionEvent e) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/vistes/VistaIniciPrograma.fxml"));
			Scene escena = new Scene(root);
			Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
			window.setScene(escena);
			window.setTitle("Menu");
			window.show();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	
	public void esborrarDades (ActionEvent e) {
        correu.setText("");
        contrasenya.clear();
        error.setText("");
	}
	
	public void logearUsuari (ActionEvent e) {
		String emailUsuari = correu.getText().trim();
        String contrasenyaUsuari = contrasenya.getText().trim();
        
        if (emailUsuari.isEmpty() || contrasenyaUsuari.isEmpty()) {
        	error.setStyle("-fx-text-fill: red;");
			error.setText("No pots deixar camps en blanc");
        } else {
        	try {
            	Class.forName("org.mariadb.jdbc.Driver");
    			
    			String urlBaseDades = "jdbc:mysql://localhost:3306/Equip2PI";
    			String usuari = "root";
    			String contrasenya = "";
    			
    			Connection c = DriverManager.getConnection(urlBaseDades, usuari, contrasenya);
    			Statement s = c.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
    			ResultSet r = s.executeQuery("SELECT * FROM Usuari");
    			boolean usuariRegistrat = false;
    			Usuari usuariLogeat = new Usuari(0, null, null, null, null, null, null);
    			
    			
    			while (r.next()) {
    				if (r.getString("Email").equals(emailUsuari)) {
    	    			String contrasenyaHash = "$2a$" + r.getString("Contrasenya").substring(4);
    					if (verificarContrasenya(contrasenyaUsuari, contrasenyaHash)) {
    						usuariRegistrat = true;
    						usuariLogeat.setIdUsuari(r.getInt("IDUsuari"));
    						usuariLogeat.setNomUsuari(r.getString("Nom"));
    						usuariLogeat.setCognomsUsuari(r.getString("Cognom"));
    						usuariLogeat.setCorreuUsuari(emailUsuari);
    						usuariLogeat.setContrasenyaUsuari(contrasenyaUsuari);
    						usuariLogeat.setDataNaixementUsuari(r.getString("DataNaixement"));
    						usuariLogeat.setPoblacioUsuari(r.getString("Poblacio"));
    					}
    				}
    			}
    			
    			if (usuariRegistrat) {
    		        error.setStyle("-fx-text-fill: green;");
    		        error.setText("Logeat correctament");
    		        
    		        Parent root = FXMLLoader.load(getClass().getResource("/vistes/VistaAplicacioBase.fxml"));
        			Scene escena = new Scene(root);
        			Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
        			window.setScene(escena);
        			window.setUserData(usuariLogeat);
        			window.setTitle("MovieRater");
        			window.show();
    			} else {
    				error.setStyle("-fx-text-fill: red;");
    				error.setText("Correu i/o contrasenya incorrectes");
    			}
    		} catch (Exception e2) {
    			System.out.println("Error: " + e2);
    		}
        }
	}
	
	public static boolean verificarContrasenya(String contrasenyaUsuari, String contrasenyaHash) {
		return BCrypt.checkpw(contrasenyaUsuari, contrasenyaHash);
	}
	
}