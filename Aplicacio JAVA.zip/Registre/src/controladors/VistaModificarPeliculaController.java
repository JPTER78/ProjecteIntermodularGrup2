package controladors;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import objectes.Pelicula;
import objectes.Usuari;

public class VistaModificarPeliculaController implements Initializable {
	
	@FXML private VBox root;
	@FXML private Button botoEixir;
	@FXML private Button botoBorrarDades;
	@FXML private Button botoModificar;
	@FXML private TextField nom;
	@FXML private TextField any;
	@FXML private TextField durada;
	@FXML private TextField genere;
	@FXML private TextField interprets;
	@FXML private TextField direccio;
	@FXML private TextField sinopsi;
	@FXML private Label error;
	
	public void eixirRegistre (ActionEvent e) {
		try {
			Class.forName("org.mariadb.jdbc.Driver");
			
			String urlBaseDades = "jdbc:mysql://localhost:3306/Equip2PI";
			String usuari = "root";
			String contrasenya = "";
			
			Connection c = DriverManager.getConnection(urlBaseDades, usuari, contrasenya);
			Statement s = c.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
			ResultSet r = s.executeQuery("SELECT * FROM Usuari");
			Usuari usuariLogeat = new Usuari(0, null, null, null, null, null, null);
			Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
			Pelicula pelicula = (Pelicula) window.getUserData();
			
			while (r.next()) {
				if (r.getInt("IDUsuari") == pelicula.getIdUser()) {
					usuariLogeat.setIdUsuari(r.getInt("IDUsuari"));
					usuariLogeat.setNomUsuari(r.getString("Nom"));
					usuariLogeat.setCognomsUsuari(r.getString("Cognom"));
					usuariLogeat.setCorreuUsuari(r.getString("Email"));
					usuariLogeat.setContrasenyaUsuari(r.getString("Contrasenya"));
					usuariLogeat.setDataNaixementUsuari(r.getString("DataNaixement"));
					usuariLogeat.setPoblacioUsuari(r.getString("Poblacio"));
				}
			}
			
			Parent root = FXMLLoader.load(getClass().getResource("/vistes/VistaModificarElement.fxml"));
			Scene escena = new Scene(root);
			window.setScene(escena);
			window.setUserData(usuariLogeat);
			window.setTitle("Modificar Element");
			window.show();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}
	
	public void esborrarDades (ActionEvent e) {
		nom.setText("");
		any.setText("");
		durada.setText("");
		genere.setText("");
		interprets.setText("");
		direccio.setText("");
		sinopsi.setText("");
        error.setText("");
	}
	
	public void modificarDades (ActionEvent e) {
		try {
			Class.forName("org.mariadb.jdbc.Driver");
			
			String urlBaseDades = "jdbc:mysql://localhost:3306/Equip2PI";
			String usuariBD = "root";
			String contrasenyaBD = "";
			
			Connection c = DriverManager.getConnection(urlBaseDades, usuariBD, contrasenyaBD);
			Statement s = c.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
			
			String nomPelicula = nom.getText().trim();
	        String anyPelicula = any.getText().trim();
	        String duradaPelicula = durada.getText().trim();
	        String generePelicula = genere.getText().trim();
	        String interpretsPelicula = interprets.getText().trim();
	        String direccioPelicula = direccio.getText().trim();
	        String sinopsiPelicula = sinopsi.getText().trim();

	        Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
			Pelicula pelicula = (Pelicula) window.getUserData();
	        
			error.setStyle("-fx-text-fill: red;");
	        if (nomPelicula.isEmpty() || anyPelicula.isEmpty() || duradaPelicula.isEmpty() || generePelicula.isEmpty() || interpretsPelicula.isEmpty() || direccioPelicula.isEmpty() || sinopsiPelicula.isEmpty()) {
	        	error.setText("Tots els camps són obligatoris");
	        } else if (!anyPelicula.matches("(19\\d{2})") && !anyPelicula.matches("(20\\d{2})")) {
				error.setText("L'any no es vàlid");
			} else if (!duradaPelicula.matches("\\d*")) {
				error.setText("La duració no es vàlida, has de escriure solament les hores");
			} else if (!duradaPelicula.matches("\\d{1,3}")) {
				error.setText("La duració no pot ser superior a 999h o inferior a 0h");
			} else {
	            try {
	    			s.executeUpdate("UPDATE Peliculas SET IDPeli = " + pelicula.getId() + ", NomPeli = '" + nomPelicula + "', Genere = '" + generePelicula + "', Nota = " + pelicula.getNota() + ", Durada = " + duradaPelicula + ", Interprets = '" + interpretsPelicula + "', Direccio = '" + direccioPelicula + "', Sinopsi = '" + sinopsiPelicula + "' WHERE IDPeli = " + pelicula.getId());
	    			error.setStyle("-fx-text-fill: green;");
	    			error.setText("Pelicula modificada correctament");
	            } catch (Exception e3) {
					error.setStyle("-fx-text-fill: red;");
					error.setText("Ha ocurrit un error inesperat, avisa al programador xd");
					System.out.println("Error: " + e3);
				}
	        }
		} catch (Exception e2) {
			error.setStyle("-fx-text-fill: red;");
			error.setText("Tots els camps són obligatoris");
		}
	}
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		Platform.runLater(() -> {
			Stage window = (Stage) root.getScene().getWindow();
			Pelicula pelicula = (Pelicula) window.getUserData();
			
			nom.setText(pelicula.getNom());
	        any.setText(pelicula.getAny()+"");
	        durada.setText(pelicula.getDurada()+"");
	        genere.setText(pelicula.getGenere());
	        interprets.setText(pelicula.getInterprets());
	        direccio.setText(pelicula.getDireccio());
	        sinopsi.setText(pelicula.getSinopsi());
		});
	}
	
}