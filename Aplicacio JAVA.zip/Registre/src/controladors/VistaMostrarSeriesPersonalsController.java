package controladors;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import objectes.Usuari;

public class VistaMostrarSeriesPersonalsController implements Initializable {
	
	@FXML private VBox root;
	@FXML private Button botoPelicules;
	@FXML private VBox vBoxMostrar;
	@FXML private Button botoEixir;
	
	public void eixirPersonals (ActionEvent e) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/vistes/VistaAplicacioBase.fxml"));
			Scene escena = new Scene(root);
			Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
			Usuari usuariApp = (Usuari) window.getUserData();
			window.setScene(escena);
			window.setUserData(usuariApp);
			window.setTitle("MovieRater");
			window.show();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	
	public void canviPelicules (ActionEvent e) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/vistes/VistaMostrarPeliculesPersonals.fxml"));
			Scene escena = new Scene(root);
			Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
			Usuari usuariApp = (Usuari) window.getUserData();
			window.setScene(escena);
			window.setUserData(usuariApp);
			window.setTitle("Mostrar Pel·licules Personals");
			window.show();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		Platform.runLater(() -> {
			Stage window = (Stage) root.getScene().getWindow();
			Usuari usuariApp = (Usuari) window.getUserData();
			String nomTaula = usuariApp.getCorreuUsuari().split("@")[0] + "SeriesPersonals";
			try {
				Class.forName("org.mariadb.jdbc.Driver");
				
				String urlBaseDades = "jdbc:mysql://localhost:3306/Equip2PI";
				String usuari = "root";
				String contrasenya = "";
				
				Connection c = DriverManager.getConnection(urlBaseDades, usuari, contrasenya);
				Statement s = c.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
				ResultSet r = s.executeQuery("SELECT * FROM " + nomTaula);

				while (r.next()) {
					Label titol = new Label(r.getString("NomSerie"));
					Label any = new Label(r.getString("Any"));
					Label duracio = new Label(r.getString("Durada"));

					titol.setPadding(new Insets(10, 10, 10, 10));
					any.setPadding(new Insets(10, 10, 10, 10));
					duracio.setPadding(new Insets(10, 10, 10, 10));
					HBox hBoxPelicula = new HBox(titol, any, duracio);
					hBoxPelicula.setAlignment(Pos.CENTER);
					vBoxMostrar.getChildren().add(hBoxPelicula);
				}
			} catch (Exception e2) {
				System.out.println("Error: " + e2);
			}
		});
	}
	
}