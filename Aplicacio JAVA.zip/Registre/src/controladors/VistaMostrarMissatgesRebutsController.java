package controladors;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import objectes.Usuari;

public class VistaMostrarMissatgesRebutsController implements Initializable {
	
	@FXML private VBox root;
	@FXML private Button botoEnviats;
	@FXML private VBox vBoxMostrar;
	@FXML private Button botoEixir;
	
	public void eixirMostrarMissatges (ActionEvent e) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/vistes/VistaAplicacioBase.fxml"));
			Scene escena = new Scene(root);
			Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
			Usuari usuariApp = (Usuari) window.getUserData();
			window.setScene(escena);
			window.setUserData(usuariApp);
			window.setTitle("MovieRater");
			window.show();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	
	public void canviEnviats (ActionEvent e) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/vistes/VistaMostrarMissatgesEnviats.fxml"));
			Scene escena = new Scene(root);
			Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
			Usuari usuariApp = (Usuari) window.getUserData();
			window.setScene(escena);
			window.setUserData(usuariApp);
			window.setTitle("Missatges Enviats");
			window.show();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	
	public String trovarNomEnviat(String idEnviar) {
		try {
			Class.forName("org.mariadb.jdbc.Driver");
			
			String urlBaseDades = "jdbc:mysql://localhost:3306/Equip2PI";
			String usuari = "root";
			String contrasenya = "";
			
			Connection c = DriverManager.getConnection(urlBaseDades, usuari, contrasenya);
			Statement s = c.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
			ResultSet r = s.executeQuery("SELECT * FROM Usuari WHERE IDUsuari = " + idEnviar);
			
			if (r.next()) {
				return r.getString("Email").split("@")[0] + "MissatgesEnviats";
			} else {
				return "";
			}
		} catch (Exception e) {
			System.out.println("Error: " + e);
			return "";
		}
	}
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		Platform.runLater(() -> {
			Stage window = (Stage) root.getScene().getWindow();
			Usuari usuariApp = (Usuari) window.getUserData();
			String nomTaula = usuariApp.getCorreuUsuari().split("@")[0] + "MissatgesRebuts";
			try {
				Class.forName("org.mariadb.jdbc.Driver");
				
				String urlBaseDades = "jdbc:mysql://localhost:3306/Equip2PI";
				String usuari = "root";
				String contrasenya = "";
				
				Connection c = DriverManager.getConnection(urlBaseDades, usuari, contrasenya);
				Statement s = c.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
				ResultSet r = s.executeQuery("SELECT * FROM " + nomTaula);

				while (r.next()) {
					Statement s2 = c.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
					ResultSet r2 = s2.executeQuery("SELECT * FROM Usuari");
					Label nom = new Label();
					while (r2.next()) {
						if (r2.getInt("IDUsuari") == r.getInt("IDEnviar")) {
							nom = new Label(r2.getString("Nom"));
						}
					}
					Label titol = new Label(r.getString("titolMissatge"));
					Label contingut = new Label(r.getString("contingutMissatge"));
					nom.setPadding(new Insets(10, 10, 10, 10));
					titol.setPadding(new Insets(10, 10, 10, 10));
					contingut.setPadding(new Insets(10, 10, 10, 10));
					Button botoLlegir = new Button();
					botoLlegir.setText("Llegir " + r.getInt("IDMissatge"));
					HBox hBoxMissatge;
					Circle circle = new Circle();
					if (r.getInt("llegit") == 0) {
						circle.setCenterX(10.0f);
						circle.setCenterY(10.0f);
						circle.setRadius(5.0f);
						circle.setFill(javafx.scene.paint.Color.RED);
						hBoxMissatge = new HBox(circle, nom, titol, contingut, botoLlegir);
					} else {
						hBoxMissatge = new HBox(nom, titol, contingut, botoLlegir);
					}
					botoLlegir.setOnAction(new EventHandler<ActionEvent>() {
                        public void handle(ActionEvent event) {
                        	try {
                        		String idMissatge = ((Button) event.getSource()).getText().split(" ")[1];
                        	    
                        	    Statement s3 = c.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
                        	    ResultSet r3 = s3.executeQuery("SELECT * FROM " + nomTaula + " WHERE IDMissatge = " + idMissatge);
                        	    
                        	    if (r3.next()) {
                        	        Statement s4 = c.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
                        	        s4.executeUpdate("UPDATE " + nomTaula + " SET llegit = 1 WHERE IDMissatge = " + idMissatge);
                        	        if (hBoxMissatge.getChildren().get(0) == circle) {
                            	        hBoxMissatge.getChildren().remove(0);
                        	        }
                        	        
                        	        String nomTaulaEnviat = trovarNomEnviat(r3.getInt("idEnviar")+"");
                        	        
                        	        String updateQuery = "UPDATE " + nomTaulaEnviat + " SET llegit = 1 WHERE idEnviar = " + r3.getInt("idEnviar") + " AND idRebre = " + r3.getInt("idRebre") + " AND titolMissatge = '" + r3.getString("titolMissatge") + "' AND contingutMissatge = '" + r3.getString("contingutMissatge") + "'";
                        	        s4.executeUpdate(updateQuery);
                        	    }
                            } catch (Exception e) {
                        		System.out.println("Error: " + e);
                        	}
                        }
                    });
					if (r.getInt("llegit") == 1) {
						hBoxMissatge.getChildren().remove(0);
					}
					hBoxMissatge.setAlignment(Pos.CENTER);
					vBoxMostrar.getChildren().add(hBoxMissatge);
				}
			} catch (Exception e2) {
				System.out.println("Error: " + e2);
			}
		});
	}
	
}