package controladors;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import objectes.Opinio;
import objectes.Usuari;

public class VistaOpinioPersonalController {
	
	@FXML private VBox root;
	@FXML private Label titol;
	@FXML private TextField nota;
	@FXML private TextArea opinio;
	@FXML private Button botoEixir;
	@FXML private Button botoBorrarDades;
	@FXML private Button botoOpinar;
	@FXML private Label error;
	
	public void eixirOpinio (ActionEvent e) {
		try {
			Class.forName("org.mariadb.jdbc.Driver");
	        
	        String urlBaseDades = "jdbc:mysql://localhost:3306/Equip2PI";
	        String usuari = "root";
	        String contrasenya = "";
	        
	        Connection c = DriverManager.getConnection(urlBaseDades, usuari, contrasenya);
	        Statement s = c.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
	        ResultSet r = s.executeQuery("SELECT * FROM Usuari");
	        Usuari usuariApp = new Usuari(0, null, null, null, null, null, null);
	        Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
	        Opinio opinioValors = (Opinio) window.getUserData();
	        
	        while (r.next()) {
	            if (r.getInt("IDUsuari") == opinioValors.getIdUsuari()) {
	                usuariApp.setIdUsuari(r.getInt("IDUsuari"));
	                usuariApp.setNomUsuari(r.getString("Nom"));
	                usuariApp.setCognomsUsuari(r.getString("Cognom"));
	                usuariApp.setCorreuUsuari(r.getString("Email"));
	                usuariApp.setContrasenyaUsuari(r.getString("Contrasenya"));
	                usuariApp.setDataNaixementUsuari(r.getString("DataNaixement"));
	                usuariApp.setPoblacioUsuari(r.getString("Poblacio"));
	            }
	        }
	        
	        if (opinioValors.getTipus() == 1) {
	        	Parent root = FXMLLoader.load(getClass().getResource("/vistes/VistaMostrarPeliculesGenerals.fxml"));
		        window.setTitle("Mostrar Pelicules Generals");
		        Scene escena = new Scene(root);
		        window.setScene(escena);
		        window.setUserData(usuariApp);
	        } else if (opinioValors.getTipus() == 2) {
	            Parent root = FXMLLoader.load(getClass().getResource("/vistes/VistaMostrarSeriesGenerals.fxml"));
	            window.setTitle("Mostrar Series Generals");
	            Scene escena = new Scene(root);
		        window.setScene(escena);
		        window.setUserData(usuariApp);
	        }
	        
		} catch (Exception e1) {
			System.out.println("Error: " + e1);
		}
	}
	
	public void esborrarDades (ActionEvent e) {
		nota.setText("");
		opinio.clear();
        error.setText("");
	}
	
	public void guardarOpinio (ActionEvent e) {
		Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
		Opinio opinioValors = (Opinio) window.getUserData();
		
		String notaUsuari = nota.getText().trim();
        String opinioUsuari = opinio.getText().trim();

    	error.setStyle("-fx-text-fill: red;");
        if (notaUsuari.isEmpty() || opinioUsuari.isEmpty()) {
			error.setText("No pots deixar camps en blanc");
        } else if (!notaUsuari.matches("\\d*")) {
			error.setText("El valor de la nota no se vàlid");
        } else if (Integer.parseInt(notaUsuari) < 0 || Integer.parseInt(notaUsuari) > 10) {
			error.setText("La nota ha de estar entre 0 i 10");
        } else {
        	try {
            	Class.forName("org.mariadb.jdbc.Driver");
    			
    			String urlBaseDades = "jdbc:mysql://localhost:3306/Equip2PI";
    			String usuari = "root";
    			String contrasenya = "";
    			
    			Connection c = DriverManager.getConnection(urlBaseDades, usuari, contrasenya);
    			Statement s = c.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
    			ResultSet r = s.executeQuery("SELECT * FROM Valoracions");
    			boolean elementValorat = false;
    			
    			while (r.next()) {
    				if (r.getInt("idElement") == opinioValors.getIdElement() && r.getInt("idUsuari") == opinioValors.getIdUsuari()) {
    					elementValorat = true;
    				}
    			}
    			
    			String tipus = "";
    			if (opinioValors.getTipus() == 1) {
    				tipus = "Pelicula";
    			} else if (opinioValors.getTipus() == 2) {
    				tipus = "Serie";
    			}
    			
    			if (!elementValorat) {
	    			s.executeUpdate("INSERT INTO Valoracions (TipusElement, idElement, idUsuari, Valoracio, Opinio) VALUES ('" + tipus + "', " + opinioValors.getIdElement() + ", " + opinioValors.getIdUsuari() + ", " + Integer.parseInt(notaUsuari) + ", '" + opinioUsuari + "')");
    		        
	    			int contValoracions = 0;
	    			int valorTotal = 0;
	    			Statement s2 = c.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
	    			ResultSet r2 = s2.executeQuery("SELECT * FROM Valoracions");
	    			while (r2.next()) {
	    				if (r2.getInt("idElement") == opinioValors.getIdElement()) {
	    					contValoracions++;
	    					valorTotal += r2.getInt("Valoracio");
	    				}
	    			}
	    			
	    			float valoracioMitja = valorTotal / contValoracions;
	    			if (tipus.equals("Pelicula")) {
		    			s.execute("UPDATE Peliculas SET Nota = " + valoracioMitja + " WHERE IDPeli = " + opinioValors.getIdElement());
	    			} else if (tipus.equals("Serie")) {
		    			s.execute("UPDATE Series SET Nota = " + valoracioMitja + " WHERE IDSerie = " + opinioValors.getIdElement());
	    			}
	    			
	    			error.setStyle("-fx-text-fill: green;");
    		        error.setText("Valoració guardada satisfactoriament");
    			} else {
    				error.setStyle("-fx-text-fill: red;");
    				error.setText("Ja has valorat aquesta obra anteriorment");
    			}
    		} catch (Exception e2) {
    	    	error.setStyle("-fx-text-fill: red;");
    			error.setText("Has introduit un caràcter no vàlid en la teva opinio");
    		}
        }
	}
	
}