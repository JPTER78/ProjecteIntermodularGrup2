package controladors;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import objectes.Cercar;
import objectes.Usuari;

public class VistaCercarElementController {
	
	@FXML private VBox root;
	@FXML private Button botoEixir;
	@FXML private Button botoBorrarDades;
	@FXML private Button botoCercar;
	@FXML private CheckBox cbPelicules;
	@FXML private CheckBox cbSeries;
	@FXML private TextField nom;
	@FXML private Label error;
	
	public void eixirLogin (ActionEvent e) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/vistes/VistaAplicacioBase.fxml"));
			Scene escena = new Scene(root);
			Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
			Usuari usuariApp = (Usuari) window.getUserData();
			window.setScene(escena);
			window.setUserData(usuariApp);
			window.setTitle("MovieRater");
			window.show();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	
	public void esborrarDades (ActionEvent e) {
		cbPelicules.setSelected(false);
		cbSeries.setSelected(false);
        nom.setText("");
        error.setText("");
	}
	
	public void cercarElements (ActionEvent e) {
		if (!nom.getText().isEmpty()) {
			Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();
			Usuari usuariApp = (Usuari) window.getUserData();
			if (cbPelicules.isSelected() && cbSeries.isSelected()) {
				Cercar cercar = new Cercar("SI", "SI", nom.getText(), usuariApp.getIdUsuari());
				try {
					Parent root = FXMLLoader.load(getClass().getResource("/vistes/VistaMostrarElement.fxml"));
					Scene escena = new Scene(root);
					window.setScene(escena);
					window.setUserData(cercar);
					window.setTitle("Mostrar Elementos");
					window.show();
				} catch (Exception e2) {
					System.out.println("Error: " + e2);
				}
			} else if (cbPelicules.isSelected()) {
				Cercar cercar = new Cercar("SI", "NO", nom.getText(), usuariApp.getIdUsuari());
				try {
					Parent root = FXMLLoader.load(getClass().getResource("/vistes/VistaMostrarElement.fxml"));
					Scene escena = new Scene(root);
					window.setScene(escena);
					window.setUserData(cercar);
					window.setTitle("Mostrar Elementos");
					window.show();
				} catch (Exception e2) {
					System.out.println("Error: " + e2);
				}
			} else if (cbSeries.isSelected()) {
				Cercar cercar = new Cercar("NO", "SI", nom.getText(), usuariApp.getIdUsuari());
				try {
					Parent root = FXMLLoader.load(getClass().getResource("/vistes/VistaMostrarElement.fxml"));
					Scene escena = new Scene(root);
					window.setScene(escena);
					window.setUserData(cercar);
					window.setTitle("Mostrar Elementos");
					window.show();
				} catch (Exception e2) {
					System.out.println("Error: " + e2);
				}
			} else {
				error.setStyle("-fx-text-fill: red;");
				error.setText("Has d'elegir al menys un tipus d'element per a cercar");
			}
		} else {
			error.setStyle("-fx-text-fill: red;");
			error.setText("Has d'escriure el nom del element");
		}
	}
	
}